package org.census;

import org.census.personnel.dataModel.dto.PositionDTOAnnotated;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;

/**
 * @author Gusev Dmitry (�������)
 * @version 1.0 (DATE: 17.12.11)
*/

@Repository        // <- for execptions translating
@Transactional     // <- methos of this dao are transactional
public class SpringJPADAO
 {
  public SpringJPADAO() {}

  @PersistenceContext // <- entity manager injection
  private EntityManager em;

  public PositionDTOAnnotated getPositionById(int id)
   {return em.find(PositionDTOAnnotated.class, id);}

  public List<PositionDTOAnnotated> getAllPositions(boolean active)
   {
    TypedQuery<PositionDTOAnnotated> query =
     em.createQuery("select p from PositionDTOAnnotated p" + (active ? " where p.deleted = 0" : ""), PositionDTOAnnotated.class);
    return query.getResultList();
   }

 }