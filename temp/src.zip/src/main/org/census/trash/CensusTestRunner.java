package org.census.trash;

import org.census.personnel.dataModel.dao.PositionDaoJdbc;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Gusev Dmitry (019gus)
 * @version 1.0 (DATE: 17.09.11)
*/

public class CensusTestRunner
 {

  public static void main(String[] args)
   {
    ApplicationContext context = new ClassPathXmlApplicationContext("spring-data-config.xml");
    PositionDaoJdbc bean = (PositionDaoJdbc) context.getBean("positionDaoJdbc");
    bean.updatePosition();
   }

 }