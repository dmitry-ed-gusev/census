package org.census.trash.hsqltest;

import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author Gusev Dmitry (019gus)
 * @version 1.0 (DATE: 17.09.11)
*/

public class HsqlTest
 {

  public static void main(String[] args)
   {
    Logger logger = Logger.getLogger(HsqlTest.class.getName());
    try
     {
      Connection c = DriverManager.getConnection("jdbc:hsqldb:file:/opt/db/testdb", "SA", "");
      logger.debug("Connection ok.");
     }
    catch (SQLException e) {logger.error("error!"); e.printStackTrace();}
   }

 }