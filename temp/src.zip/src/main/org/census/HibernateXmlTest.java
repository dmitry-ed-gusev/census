package org.census;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.census.personnel.dataModel.dto.PositionDTO;
import org.census.commons.utils.HibernateUtils;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.Iterator;
import java.util.List;

/**
 * @author Gusev Dmitry (dgusev)
 * @version 1.0 (DATE: 06.12.11)
*/

public class HibernateXmlTest
 {
  public static void main(String[] args)
   {
    Log log = LogFactory.getLog(HibernateXmlTest.class);
    log.info("Started...");

    // getting positions list
    Session newSession = HibernateUtils.getSessionFactory().openSession();
    Transaction newTransaction = newSession.beginTransaction();
    List messages = newSession.createQuery("from PositionDTO p order by p.name asc").list();
    log.info( messages.size() + " position(s) found:" );
    for (Iterator iter = messages.iterator(); iter.hasNext();)
     {
      PositionDTO position = (PositionDTO) iter.next();
      log.info("-> " + position.getName());
     }
    newTransaction.commit();
    newSession.close();

    // shutdown system
    HibernateUtils.shutdown();
   }
 }