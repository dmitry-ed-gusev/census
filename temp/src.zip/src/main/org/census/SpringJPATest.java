package org.census;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.census.personnel.dataModel.dto.PositionDTOAnnotated;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Gusev Dmitry (�������)
 * @version 1.0 (DATE: 17.12.11)
*/

public class SpringJPATest
 {

  public static void main(String[] args)
   {
    Log log = LogFactory.getLog(SpringJPATest.class);
    log.info("Spring JPA test started.");

    ApplicationContext context = new ClassPathXmlApplicationContext("META-INF/applicationContext.xml");
    SpringJPADAO springDao = context.getBean(SpringJPADAO.class);

    // one position
    log.info("position with ID=1: " + springDao.getPositionById(1).getName());
    log.info("");

    // all positions
    for (PositionDTOAnnotated position : springDao.getAllPositions(false))
     {log.info("-> " + position.getName() + " [" + position.getId() + "]");}

   }

 }