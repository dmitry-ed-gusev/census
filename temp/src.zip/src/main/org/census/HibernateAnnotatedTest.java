package org.census;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.census.personnel.dataModel.dto.PositionDTOAnnotated;
import org.census.commons.utils.HibernateUtils;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.Iterator;
import java.util.List;

/**
 * @author Gusev Dmitry (�������)
 * @version 1.0 (DATE: 12.12.11)
*/

public class HibernateAnnotatedTest
 {
  public static void main(String[] args)
   {
    Log log = LogFactory.getLog(HibernateXmlTest.class);
    log.info("Started...");

    // First unit of work
    Session session = HibernateUtils.getSessionFactory().openSession();
    Transaction tx = session.beginTransaction();
    PositionDTOAnnotated position = new PositionDTOAnnotated();
    position.setName("��������2");
    position.setUpdateUser(1);
    Integer msgId = (Integer) session.save(position);
    tx.commit();
    session.close();

    // Second unit of work
    Session newSession = HibernateUtils.getSessionFactory().openSession();
    Transaction newTransaction = newSession.beginTransaction();
    List positions = newSession.createQuery("from PositionDTOAnnotated p order by p.name asc").list();
    System.out.println(positions.size() + " position(s) found:" );
    for (Iterator iter = positions.iterator(); iter.hasNext();)
     {
      PositionDTOAnnotated pos = (PositionDTOAnnotated) iter.next();
      System.out.println(pos.getName());
     }
    newTransaction.commit();
    newSession.close();

    // Third unit of work
    Session thirdSession = HibernateUtils.getSessionFactory().openSession();
    Transaction thirdTransaction = thirdSession.beginTransaction();
    // msgId holds the identifier value of the first message
    position = (PositionDTOAnnotated) thirdSession.get(PositionDTOAnnotated.class, msgId);
    position.setName("Greetings Earthling -> 222222222222222222222222");
    thirdTransaction.commit();
    thirdSession.close();

    // Shutting down the application
    HibernateUtils.shutdown();

   }

 }