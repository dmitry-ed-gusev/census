package org.census;

import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * @author Gusev Dmitry (������� �����)
 * @version 1.0 (DATE: 18.10.11)
*/
public class Test
 {
  @SuppressWarnings({"IOResourceOpenedButNotSafelyClosed"})
  public static void main(String[] args)
   {
    Logger logger = Logger.getLogger(Test.class);
    logger.info("ok!");
    BufferedReader reader = null;
    try
     {
      reader = new BufferedReader(new FileReader("resources/census_db_mysql.sql"));
      String line;
      while((line = reader.readLine()) != null)
       {
        System.out.println(line);
       }
     }
    catch (FileNotFoundException e) {logger.error(e.getMessage());}
    catch (IOException e) {logger.error(e.getMessage());}
    finally
     {
      try {if (reader != null) {reader.close();}}
      catch (IOException e) {logger.error("Can't close BufferedReader: " + e.getMessage());}
     }
   }
 }