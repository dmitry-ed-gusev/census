package org.census;

import org.census.personnel.dataModel.dto.PositionDTOAnnotated;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.util.List;

/**
 * @author Gusev Dmitry (�������)
 * @version 1.0 (DATE: 15.12.11)
*/

public class HibernateJPATest
 {
  public static void main(String[] args)
   {
    // Start EntityManagerFactory
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("census");
    // First unit of work
    EntityManager em = emf.createEntityManager();
    EntityTransaction tx = em.getTransaction();
    tx.begin();
    PositionDTOAnnotated position = new PositionDTOAnnotated();
    position.setName("��������2");
    position.setUpdateUser(1);
    em.persist(position);
    tx.commit();
    em.close();

    // Second unit of work
    EntityManager newEm = emf.createEntityManager();
    EntityTransaction newTx = newEm.getTransaction();
    newTx.begin();
    List positions = newEm.createQuery("select p from PositionDTOAnnotated p order by p.name asc").getResultList();
    System.out.println(positions.size() + " position(s) found" );
    for (Object p : positions)
     {
      PositionDTOAnnotated pos = (PositionDTOAnnotated) p;
      System.out.println(pos.getName());
     }
    newTx.commit();
    newEm.close();
   }
 }