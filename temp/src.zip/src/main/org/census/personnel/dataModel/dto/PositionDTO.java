package org.census.personnel.dataModel.dto;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.sql.Date;

/**
 * @author Gusev Dmitry (019gus)
 * @version 1.0 (DATE: 13.09.11)
*/

public final class PositionDTO extends AbstractBaseDTO
 {
  private String name   = null;
  private int    weight = 0;

  public PositionDTO() {}

  public PositionDTO(int id, int updateUser, Date timestamp, String comment, int deleted, String name, int weight)
   {
    super(id, updateUser, timestamp, comment, deleted);
    this.name = name;
    this.weight = weight;
   }

  public String getName() {
   return name;
  }

  public void setName(String name) {
   this.name = name;
  }

  public int getWeight() {
   return weight;
  }

  public void setWeight(int weight) {
   this.weight = weight;
  }

  @Override
  public boolean isEmpty()
   {return (StringUtils.isBlank(name) || (weight <= 0));}

  @Override
  public String toString()
   {
    return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).
            append(super.toString()).
            append("name", name).
            append("weight", weight).
            toString();
   }

 }