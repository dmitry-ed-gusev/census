package org.census.personnel.dataModel.dao;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

/**
 * @author Gusev Dmitry (019gus)
 * @version 1.0 (DATE: 17.09.11)
*/

public class PositionDaoJdbc extends JdbcDaoSupport
 {
  private String sql1 = "create table t1(f1 varchar(10))";
  private String sql2 = "insert into t1 values('������')";
  private String sql3 = "shutdown";

  public void updatePosition()
   {
    //getJdbcTemplate().update(sql1);
    getJdbcTemplate().update(sql2);
    getJdbcTemplate().update(sql3);
   }

  public static void main(String[] args)
   {
    new PositionDaoJdbc().updatePosition();
   }
 }