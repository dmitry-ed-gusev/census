package org.census.personnel.dataModel.dto;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Date;

/**
 * @author Gusev Dmitry (�������)
 * @version 1.0 (DATE: 12.12.11)
*/

//@Entity
@Table(name = "POSITIONS")
public final class PositionDTOAnnotated extends AbstractBaseDTO
 {
  @Id
  @GeneratedValue
  private int    id     = 0;

  private int    updateUser = 0;
  private Date   timestamp  = null;
  private String comment    = null;
  private int    deleted    = 0;
  private String name   = null;
  private int    weight = 0;

  public int getId() {
   return id;
  }

  public void setId(int id) {
   this.id = id;
  }

  public int getUpdUser() {
   return updateUser;
  }

  public void setUpdateUser(int updateUser) {
   this.updateUser = updateUser;
  }

  public Date getUpdTimestamp() {
   return timestamp;
  }

  public void setTimestamp(Date timestamp) {
   this.timestamp = timestamp;
  }

  public String getComment() {
   return comment;
  }

  public void setComment(String comment) {
   this.comment = comment;
  }

  public int getDeleted() {
   return deleted;
  }

  public void setDeleted(int deleted) {
   this.deleted = deleted;
  }

  public String getName() {
   return name;
  }

  public void setName(String name) {
   this.name = name;
  }

  public int getWeight() {
   return weight;
  }

  public void setWeight(int weight) {
   this.weight = weight;
  }

  @Override
  public boolean isEmpty()
   {return (StringUtils.isBlank(name) || (weight <= 0));}

  @Override
  public String toString()
   {
    return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).
            append(super.toString()).
            append("name", name).
            append("weight", weight).
            toString();
   }

 }