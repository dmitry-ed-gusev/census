package org.census.personnel.web.controllers;

import org.apache.log4j.Logger;
import org.census.personnel.dataModel.mybatis.xml.PositionsMapper;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Gusev Dmitry (������� �����)
 * @version 1.0 (DATE: 04.10.11)
 */
public class PositionsJspViewController extends AbstractController
 {
  private Logger logger = Logger.getLogger(getClass().getName());
  private PositionsMapper mapper;

  public void setMapper(PositionsMapper mapper) {
   this.mapper = mapper;
  }

  @Override
  protected ModelAndView handleRequestInternal(HttpServletRequest httpServletRequest,
   HttpServletResponse httpServletResponse) throws Exception
   {
    logger.info("Jsp controller working.");
    return new ModelAndView("homeJsp", "positions", mapper.findAllPositions(true));
   }
}
