package org.census.commons.utils;

import org.apache.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import static junit.framework.Assert.assertEquals;

/**
 * @author Gusev Dmitry (������� �����)
 * @version 1.0 (DATE: 19.10.11)
*/

public class DbUtilsTest
 {
  private static final Logger logger = Logger.getLogger(DbUtilsTest.class);

  private static final String TEST_FILE_NAME = "test.sql";
  private static final String SQL_STRING1 = "select * from";
  private static final String SQL_STRING2 = "table1 where id = 1";

  @SuppressWarnings({"IOResourceOpenedButNotSafelyClosed"})
  @BeforeClass
  public static void setupOnce() throws IOException
   {
    BufferedWriter writer = null;
    try
     {
      writer = new BufferedWriter(new FileWriter(new File(TEST_FILE_NAME)));
      writer.write(SQL_STRING1);
      writer.write("\n");
      writer.write(SQL_STRING2);
      writer.flush();
     }
    finally {if (writer != null) {writer.close();}}
   }

  @Test
  public void testGetScript()
   {
    List<String> list = DbUtils.getScript(TEST_FILE_NAME);
    assertEquals("List size must be = 1!", 1, list.size());
   }

 }