package org.census;

/**
 * @author Gusev Dmitry (������� �����)
 * @version 1.0 (DATE: 06.10.11)
*/

public interface TestsDefaults
 {
  public static final String TEST_MYBATIS_CONFIG_FILE = "org/census/TestMybatisConfig.xml";
 }